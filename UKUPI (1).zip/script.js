$(document).ready(function() {

  $('#hero-slider').owlCarousel({
    loop: true,
    margin: 0,
    nav: true,
    items: 1,
    dots: false,
    smartSpeed: 1000,
    autoplay: true,
    autoplayTimeout: 5000,
    autoplayHoverPause: true,
    responsive: {
      0: {

      },
      600: {

      },
      1000: {

      }
    }
  })
});

document.addEventListener('DOMContentLoaded', function() {

  var heading = document.querySelector('.slider1 h1');

  setTimeout(function() {
    heading.classList.add('show');
  }, 700);
});
function updateProgressBar() {
  const { scrollTop, scrollHeight } = document.documentElement;
  const windowHeight = window.innerHeight;
  const scrollPercentage = (scrollTop / (scrollHeight - windowHeight)) * 100;
  document.getElementById('progressBar').style.width = scrollPercentage + '%';
}

window.addEventListener('scroll', updateProgressBar);
  document.addEventListener("DOMContentLoaded", function() {
    var textNosotros = document.querySelector(".text-nosotros p");

    function isElementInViewport(el) {
      var rect = el.getBoundingClientRect();
      return (
        rect.top >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
      );
    }

    function animateIfVisible() {
      if (isElementInViewport(textNosotros)) {
        textNosotros.classList.add("animate");
      }
    }

    animateIfVisible();

    window.addEventListener("scroll", function() {
      animateIfVisible();
    });
  });
  document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');


    function realizarBusqueda() {
      const searchTerm = searchInput.value.trim();
      
      alert(`Buscando: ${searchTerm}`);
    
    }


    searchButton.addEventListener('click', function(event) {
      event.preventDefault();
      realizarBusqueda();
    });


    searchInput.addEventListener('keypress', function(event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        realizarBusqueda();
      }
    });
  });
document.addEventListener("DOMContentLoaded", function() {
  
    window.addEventListener("load", function() {
        var preloader = document.querySelector(".preloader");
        preloader.style.display = "none";
    });
});
AOS.init({
  duration: 1200,
})

